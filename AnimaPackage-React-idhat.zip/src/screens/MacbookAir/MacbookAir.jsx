import React from "react";
import "./style.css";

export const MacbookAir = () => {
  return (
    <div className="macbook-air">
      <div className="div">
        <div className="overlap">
          <div className="navbar">
            <div className="text-wrapper">Home</div>
            <div className="text-wrapper-2">Shop</div>
            <div className="text-wrapper-3">About Us</div>
            <div className="text-wrapper-4">Blog</div>
            <div className="text-wrapper-5">Contact Us</div>
            <div className="text-wrapper-6">Log In</div>
            <img className="tabler-shopping-bag" alt="Tabler shopping bag" src="/img/tabler-shopping-bag.svg" />
            <img className="majesticons-search" alt="Majesticons search" src="/img/majesticons-search-line.svg" />
            <div className="rectangle" />
          </div>
          <img className="frame" alt="Frame" src="/img/frame-13.png" />
        </div>
        <div className="frame-2">
          <div className="overlap-group">
            <img className="pngwing" alt="Pngwing" src="/img/pngwing-2.png" />
            <p className="enjoy-with">
              <span className="span">Enjoy </span>
              <span className="text-wrapper-7">With</span>
            </p>
          </div>
          <div className="text-wrapper-8">HEADPHONE</div>
          <div className="div-wrapper">
            <div className="text-wrapper-9">Buy</div>
          </div>
        </div>
        <div className="frame-3">
          <div className="div-wrapper">
            <div className="text-wrapper-10">Buy</div>
          </div>
          <div className="overlap-2">
            <img
              className="apple-watch-SE"
              alt="Apple watch SE"
              src="/img/apple-watch-se-2022-gear-removebg-preview-1.png"
            />
            <p className="now-in-all-colour">
              <span className="text-wrapper-11">Now In All</span>
              <span className="text-wrapper-12">&nbsp;</span>
              <span className="text-wrapper-13">Colour</span>
              <span className="text-wrapper-12">&nbsp;</span>
            </p>
          </div>
        </div>
        <div className="frame-4">
          <div className="overlap-3">
            <div className="text-wrapper-14">SPEAKER</div>
            <div className="text-wrapper-15">NEW</div>
            <img className="img" alt="Img" src="/img/5296810f9b00f0fa1af8765e7447ee9e-1-removebg-preview-1.png" />
          </div>
          <div className="div-wrapper">
            <div className="text-wrapper-16">Buy</div>
          </div>
        </div>
        <div className="overlap-wrapper">
          <div className="overlap-4">
            <div className="overlap-5">
              <div className="text-wrapper-17">Buy</div>
            </div>
            <div className="overlap-6">
              <img className="laptop" alt="Laptop" src="/img/laptop-1.png" />
              <div className="text-wrapper-18">LAPTOP</div>
            </div>
            <div className="text-wrapper-19">THIN</div>
          </div>
        </div>
        <div className="frame-5">
          <div className="overlap-7">
            <div className="text-wrapper-20">GAMING</div>
            <div className="rectangle-2" />
            <div className="text-wrapper-21">Buy</div>
            <img className="pngwing-2" alt="Pngwing" src="/img/pngwing-4.png" />
          </div>
          <div className="text-wrapper-22">Play</div>
        </div>
        <div className="overlap-group-wrapper">
          <div className="overlap-8">
            <div className="overlap-9">
              <img className="img-2" alt="Img" src="/img/83e724c6b5df327fc96f9c05d3ccc2ce-removebg-preview-1.png" />
              <div className="text-wrapper-23">GAMING</div>
              <div className="text-wrapper-24">CONSOLE</div>
            </div>
            <div className="overlap-10">
              <div className="rectangle-3" />
              <div className="text-wrapper-25">Buy</div>
            </div>
          </div>
        </div>
        <div className="frame-6">
          <img className="iconoir-delivery" alt="Iconoir delivery" src="/img/iconoir-delivery-truck.svg" />
          <div className="text-wrapper-26">Free Shipping</div>
          <div className="text-wrapper-27">Money Guarantee</div>
          <div className="text-wrapper-28">Online Support 24/7</div>
          <div className="text-wrapper-29">Seecure Payment</div>
          <p className="p">Free Shiping On All Order</p>
          <div className="text-wrapper-30">30 day money back</div>
          <div className="text-wrapper-31">Technical Support 24/7</div>
          <div className="text-wrapper-32">All Cards Accepted</div>
          <img className="ph-wallet-light" alt="Ph wallet light" src="/img/ph-wallet-light.svg" />
          <img className="bx-support" alt="Bx support" src="/img/bx-support.svg" />
          <img className="ri-money-dollar" alt="Ri money dollar" src="/img/ri-money-dollar-circle-line.svg" />
        </div>
        <div className="frame-7">
          <div className="overlap-11">
            <div className="frame-8">
              <div className="overlap-group-2">
                <div className="text-wrapper-33">FINE</div>
                <div className="text-wrapper-34">SMILE</div>
              </div>
              <div className="text-wrapper-35">Summer Sale</div>
              <div className="text-wrapper-36">Beats Solo Air</div>
              <p className="text-wrapper-37">Feel The Reality Of Every Beat</p>
              <p className="text-wrapper-38">
                If you are looking for an efficient wireless headset, then this boAt headset is ideal for you
              </p>
              <div className="overlap-12">
                <div className="text-wrapper-39">BUY</div>
              </div>
            </div>
            <img className="pngwing-3" alt="Pngwing" src="/img/pngwing-8.png" />
          </div>
        </div>
        <div className="frame-9">
          <div className="overlap-13">
            <div className="frame-10">
              <div className="overlap-group-3">
                <div className="text-wrapper-33">HAPPY</div>
                <div className="text-wrapper-34">HOURS</div>
              </div>
              <div className="text-wrapper-35">Summer Sale</div>
              <div className="text-wrapper-36">Beats Solo Air</div>
              <p className="text-wrapper-37">Feel The Reality Of Every Beat</p>
              <p className="text-wrapper-38">
                If you are looking for an efficient wireless watch, then this Amazefit watch is ideal for you
              </p>
              <div className="overlap-12">
                <div className="text-wrapper-40">BUY</div>
              </div>
            </div>
            <img
              className="element"
              alt="Element"
              src="/img/04-369a1132-57b8-4087-81c2-2939586afca7-1512x-removebg-preview-1.png"
            />
          </div>
        </div>
        <div className="frame-11">
          <div className="overlap-14">
            <div className="rectangle-4" />
            <img className="pngwing-4" alt="Pngwing" src="/img/pngwing-9.png" />
            <div className="ellipse" />
            <div className="text-wrapper-41">Sale!</div>
          </div>
          <div className="pngwing-wrapper">
            <img className="pngwing-5" alt="Pngwing" src="/img/pngwing-10.png" />
          </div>
          <div className="img-wrapper">
            <img className="pngwing-6" alt="Pngwing" src="/img/pngwing-11.png" />
          </div>
          <div className="overlap-15">
            <img className="pngwing-7" alt="Pngwing" src="/img/pngwing-12.png" />
          </div>
          <div className="pngwing-com-wrapper">
            <img className="pngwing-com" alt="Pngwing com" src="/img/pngwing-com-2022-11-25t192325-1.png" />
          </div>
          <div className="overlap-16">
            <img className="pngwing-com-2" alt="Pngwing com" src="/img/pngwing-com-2022-11-25t192510-1.png" />
            <div className="ellipse-2" />
            <div className="text-wrapper-42">Sale!</div>
          </div>
          <div className="overlap-17">
            <div className="rectangle-5" />
            <img className="pngwing-com-3" alt="Pngwing com" src="/img/pngwing-com-2022-11-25t192954-1.png" />
          </div>
          <div className="overlap-18">
            <img className="pngwing-com-4" alt="Pngwing com" src="/img/pngwing-com-2022-11-25t193043-1.png" />
          </div>
          <div className="text-wrapper-43">JBL Headphone</div>
          <div className="text-wrapper-44">HP Laptop</div>
          <div className="text-wrapper-45">Apple Watch</div>
          <div className="text-wrapper-46">HP Monitor</div>
          <div className="text-wrapper-47">Dell Monitor</div>
          <div className="text-wrapper-48">Acer Laptop</div>
          <div className="text-wrapper-49">Apple Headphone</div>
          <div className="text-wrapper-50">Boat Headphone</div>
          <div className="text-wrapper-51">$50</div>
          <div className="text-wrapper-52">$470</div>
          <div className="text-wrapper-53">$199</div>
          <div className="text-wrapper-54">$500</div>
          <div className="text-wrapper-55">$550</div>
          <div className="text-wrapper-56">$490</div>
          <div className="text-wrapper-57">$150</div>
          <div className="text-wrapper-58">$50</div>
          <div className="text-wrapper-59">Best Seller Products</div>
        </div>
        <div className="frame-12">
          <img className="mask-group" alt="Mask group" src="/img/mask-group-2.png" />
          <div className="text-wrapper-60">Recent News</div>
          <img className="mask-group-2" alt="Mask group" src="/img/mask-group-1.png" />
          <img className="mask-group-3" alt="Mask group" src="/img/mask-group.png" />
          <p className="text-wrapper-61">How to choose perfect gadgets</p>
          <p className="text-wrapper-62">How to choose perfect gadgets</p>
          <p className="text-wrapper-63">How to choose perfect gadgets</p>
          <p className="october">
            <span className="text-wrapper-64">O</span>
            <span className="text-wrapper-65">ctober 5, 2022</span>
          </p>
          <p className="october-2">
            <span className="text-wrapper-64">O</span>
            <span className="text-wrapper-65">ctober 5, 2022</span>
          </p>
          <p className="october-3">
            <span className="text-wrapper-64">O</span>
            <span className="text-wrapper-65">ctober 5, 2022</span>
          </p>
          <p className="text-wrapper-66">
            If you are looking for an efficient wireless watch, then this Amazefit watch is ideal for you
          </p>
          <p className="text-wrapper-67">
            If you are looking for an efficient laptop, then this HP laptop is ideal for you
          </p>
          <p className="text-wrapper-68">If you are looking for an efficient AR, then this AR is ideal for you</p>
        </div>
        <div className="frame-13">
          <img className="pngwing-com-5" alt="Pngwing com" src="/img/pngwing-com-2022-11-28t110935-1.png" />
          <img className="boat-logo-removebg" alt="Boat logo removebg" src="/img/boat-logo-removebg-preview-1.png" />
          <img className="apple-logo" alt="Apple logo" src="/img/apple-logo-1.png" />
          <img className="dell-logo" alt="Dell logo" src="/img/dell-logo-1.png" />
          <img className="amazfit-logo" alt="Amazfit logo" src="/img/amazfit-logo-1.png" />
          <img className="unity-technologies" alt="Unity technologies" src="/img/unity-technologies-logo-1.png" />
        </div>
        <div className="frame-14">
          <div className="text-wrapper-69">Quick Links</div>
          <div className="text-wrapper-70">Contact</div>
          <div className="text-wrapper-71">Subscribe To Our Email</div>
          <div className="text-wrapper-72">For Latest Offers</div>
          <div className="text-wrapper-73">Home</div>
          <p className="text-wrapper-74">+91 975 166 177 0</p>
          <div className="text-wrapper-75">About</div>
          <div className="text-wrapper-76">basim1080@gmail.com</div>
          <div className="text-wrapper-77">Shop</div>
          <div className="text-wrapper-78">Tirunelveli</div>
          <div className="text-wrapper-79">Follow Us</div>
          <div className="overlap-19">
            <div className="overlap-group-4">
              <div className="text-wrapper-80">Subscribe</div>
            </div>
            <div className="text-wrapper-81">Enter Your Email</div>
          </div>
          <div className="ic-outline-mode-wrapper">
            <img className="ic-outline-mode" alt="Ic outline mode" src="/img/ic-outline-mode-comment.svg" />
          </div>
          <img className="ph-linkedin-logo" alt="Ph linkedin logo" src="/img/ph-linkedin-logo.svg" />
          <img className="ph-facebook-logo" alt="Ph facebook logo" src="/img/ph-facebook-logo.svg" />
          <img className="ph-instagram-logo" alt="Ph instagram logo" src="/img/ph-instagram-logo.svg" />
          <img className="ph-twitter-logo" alt="Ph twitter logo" src="/img/ph-twitter-logo.svg" />
        </div>
      </div>
    </div>
  );
};
