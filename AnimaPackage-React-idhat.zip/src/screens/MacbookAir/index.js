export { MacbookAir } from "./MacbookAir";
